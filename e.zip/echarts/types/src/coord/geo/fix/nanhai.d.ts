import { GeoJSONRegion } from '../Region.js';
export default function fixNanhai(mapType: string, regions: GeoJSONRegion[]): void;
