import { GeoJSONRegion } from '../Region.js';
export default function fixGeoCoords(mapType: string, region: GeoJSONRegion): void;
