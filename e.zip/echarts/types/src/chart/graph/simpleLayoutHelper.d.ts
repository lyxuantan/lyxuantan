import GraphSeriesModel from './GraphSeries.js';
import Graph from '../../data/Graph.js';
export declare function simpleLayout(seriesModel: GraphSeriesModel): void;
export declare function simpleLayoutEdge(graph: Graph, seriesModel: GraphSeriesModel): void;
