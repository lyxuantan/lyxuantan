import SeriesModel from '../../model/Series.js';
export default function enableAriaDecalForTree(seriesModel: SeriesModel): void;
