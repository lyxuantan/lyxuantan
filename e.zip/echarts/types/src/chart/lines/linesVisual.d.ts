import { StageHandler } from '../../util/types.js';
declare const linesVisual: StageHandler;
export default linesVisual;
