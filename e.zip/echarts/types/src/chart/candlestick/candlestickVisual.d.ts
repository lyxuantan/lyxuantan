import { StageHandler } from '../../util/types.js';
declare const candlestickVisual: StageHandler;
export default candlestickVisual;
