import { ECUnitOption } from '../../util/types.js';
export default function brushPreprocessor(option: ECUnitOption, isNew: boolean): void;
