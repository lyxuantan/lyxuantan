import { StageHandler } from '../../util/types.js';
declare const dataZoomProcessor: StageHandler;
export default dataZoomProcessor;
