import { EChartsExtensionInstallRegisters } from '../../extension.js';
export default function installDataZoomAction(registers: EChartsExtensionInstallRegisters): void;
