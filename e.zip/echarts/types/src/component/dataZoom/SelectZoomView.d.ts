import DataZoomView from './DataZoomView.js';
declare class SelectDataZoomView extends DataZoomView {
    static type: string;
    type: string;
}
export default SelectDataZoomView;
