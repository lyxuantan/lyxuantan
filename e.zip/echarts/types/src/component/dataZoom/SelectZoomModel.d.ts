import DataZoomModel from './DataZoomModel.js';
declare class SelectDataZoomModel extends DataZoomModel {
    static type: string;
    type: string;
}
export default SelectDataZoomModel;
