export declare function installLegendAction(registers: any): void;
