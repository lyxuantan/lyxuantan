import { EChartsExtensionInstallRegisters } from '../../extension.js';
export default function installScrollableLegendAction(registers: EChartsExtensionInstallRegisters): void;
