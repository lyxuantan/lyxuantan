import GlobalModel from '../../model/Global.js';
export default function legendFilter(ecModel: GlobalModel): void;
